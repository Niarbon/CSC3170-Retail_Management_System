
-- --------------------------------------------------------

--
-- 表的结构 `purchase_order`
--

CREATE TABLE `purchase_order` (
  `purchase_order_id` int(10) UNSIGNED NOT NULL,
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(10) UNSIGNED NOT NULL,
  `total_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `receive_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `purchase_order`
--

INSERT INTO `purchase_order` (`purchase_order_id`, `supplier_id`, `employee_id`, `total_price`, `receive_time`, `created_at`, `updated_at`) VALUES
(1, 2, 6, '1910.00', '2025-02-18 14:00:00', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(2, 1, 2, '1680.00', '2025-03-01 09:30:00', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 3, 6, '1015.00', '2025-03-10 11:00:00', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 4, 2, '1760.00', '2025-03-15 15:00:00', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 1, 1, '312.00', '2026-04-15 21:12:30', '2026-04-15 13:12:30', '2026-04-15 13:12:30'),
(6, 1, 1, '220.00', '2026-04-15 21:12:37', '2026-04-15 13:12:37', '2026-04-15 13:12:37');
