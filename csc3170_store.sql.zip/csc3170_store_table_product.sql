
-- --------------------------------------------------------

--
-- 表的结构 `product`
--

CREATE TABLE `product` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sell_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `barcode` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `product`
--

INSERT INTO `product` (`product_id`, `category_id`, `supplier_id`, `product_name`, `cost_price`, `sell_price`, `barcode`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'Potato Chips Original', '3.20', '6.00', '6902345600001', '原味薯片', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(2, 1, 2, 'Chocolate Biscuit', '4.00', '7.50', '6902345600002', '巧克力饼干', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 1, 2, 'Gummy Bears 100g', '2.50', '5.00', '6902345600003', '橡皮熊软糖', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 2, 1, 'Whole Milk 1L', '5.00', '8.50', '6902345600004', '全脂牛奶', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 2, 1, 'Strawberry Yogurt 200g', '3.50', '6.00', '6902345600005', '草莓酸奶', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(6, 2, 1, 'Cheese Slice 10pcs', '8.00', '14.00', '6902345600006', '切片奶酪', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(7, 3, 7, 'Apple 1kg', '5.00', '9.00', '6902345600007', '苹果', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(8, 3, 7, 'Banana 1kg', '3.00', '5.50', '6902345600008', '香蕉', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(9, 3, 7, 'Cherry Tomato 500g', '4.00', '7.00', '6902345600009', '小番茄', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(10, 4, 3, 'Pork Dumpling 500g', '9.00', '15.00', '6902345600010', '猪肉水饺', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(11, 4, 3, 'Tang Yuan 400g', '7.00', '12.00', '6902345600011', '汤圆', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(12, 5, 4, 'Shampoo 400ml', '12.00', '22.00', '6902345600012', '洗发水', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(13, 5, 4, 'Body Wash 500ml', '10.00', '18.00', '6902345600013', '沐浴露', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(14, 6, 5, 'Ballpoint Pen 10pcs', '4.00', '8.00', '6902345600014', '圆珠笔套装', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(15, 6, 5, 'A4 Paper 500 sheets', '15.00', '25.00', '6902345600015', 'A4复印纸', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(16, 7, 6, 'Dish Soap 500ml', '5.00', '9.50', '6902345600016', '洗洁精', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(17, 7, 6, 'Trash Bags 30pcs', '4.50', '8.00', '6902345600017', '垃圾袋', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(18, 7, 6, 'Paper Towel 6 rolls', '8.00', '14.00', '6902345600018', '厨房纸巾', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(19, 1, 1, 'Green Tea 500ml', '2.80', '4.50', '6901234567890', 'Bottled green tea', 1, '2026-04-15 13:12:30', '2026-04-15 13:12:30');
