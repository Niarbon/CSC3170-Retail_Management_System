
-- --------------------------------------------------------

--
-- 表的结构 `member`
--

CREATE TABLE `member` (
  `member_id` int(10) UNSIGNED NOT NULL,
  `member_name` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `join_date` date NOT NULL DEFAULT '0000-00-00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `member`
--

INSERT INTO `member` (`member_id`, `member_name`, `phone_number`, `points`, `join_date`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Michael Luo', '13700000001', 1200, '2023-04-10', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(2, 'Sophie Tang', '13700000002', 850, '2023-07-22', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 'William Xiao', '13700000003', 3400, '2022-12-05', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 'Emma Fang', '13700000004', 200, '2024-01-18', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 'Oliver Jiang', '13700000005', 5600, '2022-05-30', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(6, 'Chloe Bai', '13700000006', 750, '2023-09-09', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(7, 'Ethan Gong', '13700000007', 1100, '2024-03-01', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(8, 'Mia Deng', '13700000008', 2900, '2023-02-14', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(9, 'Liam Hou', '13700000009', 430, '2024-06-20', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(10, 'Ava Peng', '13700000010', 6800, '2021-11-11', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24');
