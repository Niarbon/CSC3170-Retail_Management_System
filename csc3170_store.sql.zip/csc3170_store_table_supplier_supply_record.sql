
-- --------------------------------------------------------

--
-- 表的结构 `supplier_supply_record`
--

CREATE TABLE `supplier_supply_record` (
  `supply_record_id` int(10) UNSIGNED NOT NULL,
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `purchase_item_id` int(10) UNSIGNED NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `received_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `supplier_supply_record`
--

INSERT INTO `supplier_supply_record` (`supply_record_id`, `supplier_id`, `product_id`, `purchase_item_id`, `unit_price`, `quantity`, `received_at`) VALUES
(1, 2, 1, 1, '3.20', 300, '2025-02-18 14:00:00'),
(2, 2, 2, 2, '4.00', 200, '2025-02-18 14:00:00'),
(3, 2, 3, 3, '2.50', 60, '2025-02-18 14:00:00'),
(4, 1, 4, 4, '5.00', 100, '2025-03-01 09:30:00'),
(5, 1, 5, 5, '3.50', 200, '2025-03-01 09:30:00'),
(6, 1, 6, 6, '8.00', 60, '2025-03-01 09:30:00'),
(7, 3, 10, 7, '9.00', 70, '2025-03-10 11:00:00'),
(8, 3, 11, 8, '7.00', 55, '2025-03-10 11:00:00'),
(10, 4, 12, 9, '12.00', 80, '2025-03-15 15:00:00'),
(11, 4, 13, 10, '10.00', 80, '2025-03-15 15:00:00'),
(13, 1, 1, 11, '2.60', 120, '2026-04-15 21:12:30'),
(14, 1, 1, 12, '2.75', 80, '2026-04-15 21:12:37');
