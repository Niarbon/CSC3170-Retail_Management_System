
-- --------------------------------------------------------

--
-- 表的结构 `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `supplier_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_name`, `contact_person`, `phone_number`, `address`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Sunrise Dairy Ltd.', 'Jack Liu', '13800000003', 'Zone B, Foshan', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(2, 'Ocean Snack Factory', 'Amy Zhang', '13800000004', 'Industrial Park, Zhuhai', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 'Green Valley Frozen', 'Bob Huang', '13800000005', 'Cold Chain Hub, Dongguan', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 'CleanLife Personal Care', 'Sara Wu', '13800000006', 'Chemical Zone, Zhongshan', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 'OfficeMax Supplies', 'Kevin Li', '13800000007', 'Trade Center, Jiangmen', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(6, 'HomeEase Products', 'Nancy Zhao', '13800000008', 'Export Zone, Huizhou', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(7, 'Golden Grain Co.', 'Lisa Chen', '13800000009', 'District 3, Shenzhen', 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(8, 'Fresh Farm Supply', 'Chen Wei', '13900000001', 'Shenzhen, China', 1, '2026-04-15 13:12:30', '2026-04-15 13:12:30');
