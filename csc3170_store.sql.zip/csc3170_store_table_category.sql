
-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE `category` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Snacks', '零食类，含薯片、饼干、糖果', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(2, 'Dairy', '乳制品，含牛奶、酸奶、奶酪', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 'Fresh Produce', '新鲜蔬菜水果', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 'Frozen Foods', '冷冻食品，含速冻水饺、汤圆', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 'Personal Care', '个人护理，含洗发水、沐浴露', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(6, 'Stationery', '文具办公用品', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(7, 'Household', '家居日用品', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(8, 'Beverages', 'Drinks and liquid refreshments', '2026-04-15 13:12:30', '2026-04-15 13:12:30');
