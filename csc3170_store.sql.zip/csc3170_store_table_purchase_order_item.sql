
-- --------------------------------------------------------

--
-- 表的结构 `purchase_order_item`
--

CREATE TABLE `purchase_order_item` (
  `purchase_item_id` int(10) UNSIGNED NOT NULL,
  `purchase_order_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `purchase_order_item`
--

INSERT INTO `purchase_order_item` (`purchase_item_id`, `purchase_order_id`, `product_id`, `unit_price`, `quantity`, `subtotal`) VALUES
(1, 1, 1, '3.20', 300, '960.00'),
(2, 1, 2, '4.00', 200, '800.00'),
(3, 1, 3, '2.50', 60, '150.00'),
(4, 2, 4, '5.00', 100, '500.00'),
(5, 2, 5, '3.50', 200, '700.00'),
(6, 2, 6, '8.00', 60, '480.00'),
(7, 3, 10, '9.00', 70, '630.00'),
(8, 3, 11, '7.00', 55, '385.00'),
(9, 4, 12, '12.00', 80, '960.00'),
(10, 4, 13, '10.00', 80, '800.00'),
(11, 5, 1, '2.60', 120, '312.00'),
(12, 6, 1, '2.75', 80, '220.00');
