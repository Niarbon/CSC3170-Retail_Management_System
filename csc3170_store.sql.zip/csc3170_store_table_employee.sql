
-- --------------------------------------------------------

--
-- 表的结构 `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(10) UNSIGNED NOT NULL,
  `employee_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary` decimal(10,2) NOT NULL DEFAULT '0.00',
  `job_position` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hire_date` date NOT NULL,
  `leave_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `employee`
--

INSERT INTO `employee` (`employee_id`, `employee_name`, `salary`, `job_position`, `phone_number`, `hire_date`, `leave_date`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Alice Zhang', '6500.00', 'Resigned', '13800000001', '2026-04-01', '2026-04-15', 0, '2026-04-15 13:12:16', '2026-04-15 13:12:16'),
(2, 'Bob Li', '7200.00', 'Supervisor', '13800000011', '2022-06-15', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 'Carol Wang', '5800.00', 'Cashier', '13800000012', '2023-08-20', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 'David Chen', '8500.00', 'Manager', '13800000013', '2021-01-10', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 'Eva Liu', '6000.00', 'Cashier', '13800000014', '2024-02-01', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(6, 'Frank Huang', '7000.00', 'Warehouse Staff', '13800000015', '2022-11-05', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(7, 'Grace Zhou', '5500.00', 'Cashier', '13800000016', '2024-05-18', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(8, 'Henry Wu', '9000.00', 'Store Manager', '13800000017', '2020-07-01', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(9, 'Iris Sun', '6200.00', 'Cashier', '13800000018', '2023-01-15', NULL, 1, '2026-04-15 13:12:24', '2026-04-15 13:12:24');
