
-- --------------------------------------------------------

--
-- 表的结构 `sales_transaction`
--

CREATE TABLE `sales_transaction` (
  `transaction_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(10) UNSIGNED NOT NULL,
  `member_id` int(10) UNSIGNED DEFAULT NULL,
  `transaction_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `sales_transaction`
--

INSERT INTO `sales_transaction` (`transaction_id`, `employee_id`, `member_id`, `transaction_time`, `total_price`, `discount`, `payment_method`, `created_at`, `updated_at`) VALUES
(1, 3, 1, '2025-03-20 09:15:00', '22.00', '0.00', 'CASH', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(2, 5, 3, '2025-03-20 11:30:00', '47.50', '2.50', 'CARD', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(3, 3, NULL, '2025-03-20 14:00:00', '29.50', '0.00', 'MOBILE_PAY', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(4, 7, 5, '2025-03-21 10:20:00', '64.00', '5.00', 'CARD', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(5, 9, 8, '2025-03-21 16:45:00', '35.50', '0.00', 'CASH', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(6, 3, 2, '2025-03-22 09:00:00', '41.00', '0.00', 'MOBILE_PAY', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(7, 7, 10, '2025-03-23 13:30:00', '58.00', '3.00', 'BANK_TRANSFER', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(8, 5, 4, '2025-03-24 10:10:00', '19.50', '0.00', 'CASH', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(9, 9, 6, '2025-03-25 15:00:00', '52.00', '2.00', 'CARD', '2026-04-15 13:12:24', '2026-04-15 13:12:24'),
(10, 3, 7, '2025-03-26 17:30:00', '73.00', '0.00', 'MOBILE_PAY', '2026-04-15 13:12:24', '2026-04-15 13:12:24');
