
--
-- 转储表的索引
--

--
-- 表的索引 `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `uq_category_name` (`category_name`);

--
-- 表的索引 `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `uq_employee_phone` (`phone_number`),
  ADD KEY `idx_employee_phone_number` (`phone_number`);

--
-- 表的索引 `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD UNIQUE KEY `uq_inventory_product` (`product_id`),
  ADD KEY `idx_inventory_quantity` (`quantity`);

--
-- 表的索引 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `uq_member_phone` (`phone_number`),
  ADD KEY `idx_member_phone_number` (`phone_number`);

--
-- 表的索引 `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `uq_product_barcode` (`barcode`),
  ADD UNIQUE KEY `uq_product_name_supplier` (`supplier_id`,`product_name`),
  ADD KEY `idx_product_barcode` (`barcode`),
  ADD KEY `idx_product_category_id` (`category_id`),
  ADD KEY `idx_product_supplier_id` (`supplier_id`);

--
-- 表的索引 `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`purchase_order_id`),
  ADD KEY `idx_purchase_order_supplier_id` (`supplier_id`),
  ADD KEY `idx_purchase_order_employee_id` (`employee_id`),
  ADD KEY `idx_purchase_order_receive_time` (`receive_time`);

--
-- 表的索引 `purchase_order_item`
--
ALTER TABLE `purchase_order_item`
  ADD PRIMARY KEY (`purchase_item_id`),
  ADD UNIQUE KEY `uq_purchase_order_product` (`purchase_order_id`,`product_id`),
  ADD KEY `idx_purchase_order_item_product_id` (`product_id`);

--
-- 表的索引 `sales_transaction`
--
ALTER TABLE `sales_transaction`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `idx_sales_transaction_employee_id` (`employee_id`),
  ADD KEY `idx_sales_transaction_member_id` (`member_id`),
  ADD KEY `idx_sales_transaction_time` (`transaction_time`);

--
-- 表的索引 `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`),
  ADD UNIQUE KEY `uq_supplier_name` (`supplier_name`),
  ADD UNIQUE KEY `uq_supplier_phone` (`phone_number`),
  ADD KEY `idx_supplier_phone_number` (`phone_number`);

--
-- 表的索引 `supplier_supply_record`
--
ALTER TABLE `supplier_supply_record`
  ADD PRIMARY KEY (`supply_record_id`),
  ADD KEY `fk_supply_record_product` (`product_id`),
  ADD KEY `fk_supply_record_purchase_item` (`purchase_item_id`),
  ADD KEY `idx_supply_record_supplier_product` (`supplier_id`,`product_id`);

--
-- 表的索引 `transaction_item`
--
ALTER TABLE `transaction_item`
  ADD PRIMARY KEY (`transaction_item_id`),
  ADD UNIQUE KEY `uq_transaction_product` (`transaction_id`,`product_id`),
  ADD KEY `idx_transaction_item_product_id` (`product_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- 使用表AUTO_INCREMENT `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- 使用表AUTO_INCREMENT `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `purchase_order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `purchase_order_item`
--
ALTER TABLE `purchase_order_item`
  MODIFY `purchase_item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用表AUTO_INCREMENT `sales_transaction`
--
ALTER TABLE `sales_transaction`
  MODIFY `transaction_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `supplier_supply_record`
--
ALTER TABLE `supplier_supply_record`
  MODIFY `supply_record_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 使用表AUTO_INCREMENT `transaction_item`
--
ALTER TABLE `transaction_item`
  MODIFY `transaction_item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- 限制导出的表
--

--
-- 限制表 `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `fk_inventory_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_product_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`) ON UPDATE CASCADE;

--
-- 限制表 `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD CONSTRAINT `fk_purchase_order_employee` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_purchase_order_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`) ON UPDATE CASCADE;

--
-- 限制表 `purchase_order_item`
--
ALTER TABLE `purchase_order_item`
  ADD CONSTRAINT `fk_purchase_item_order` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order` (`purchase_order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_purchase_item_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON UPDATE CASCADE;

--
-- 限制表 `sales_transaction`
--
ALTER TABLE `sales_transaction`
  ADD CONSTRAINT `fk_sales_transaction_employee` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sales_transaction_member` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- 限制表 `supplier_supply_record`
--
ALTER TABLE `supplier_supply_record`
  ADD CONSTRAINT `fk_supply_record_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_supply_record_purchase_item` FOREIGN KEY (`purchase_item_id`) REFERENCES `purchase_order_item` (`purchase_item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_supply_record_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `transaction_item`
--
ALTER TABLE `transaction_item`
  ADD CONSTRAINT `fk_transaction_item_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_transaction_item_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `sales_transaction` (`transaction_id`) ON DELETE CASCADE ON UPDATE CASCADE;
